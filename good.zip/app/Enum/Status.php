<?php
namespace App\Enum;

class Status {

 	const ACTIVE = 'yes';
 	const INACTIVE = 'no';

}