<?php
namespace App\Enum;

class Access {

 	const SUPERADMIN = 1;

}