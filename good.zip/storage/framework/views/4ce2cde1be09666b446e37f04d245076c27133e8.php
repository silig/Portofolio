<?php if(count($errors) > 0): ?>
  	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  		<div class="alert alert-danger">
			<button type="button" class="close" data-dismiss="alert">&times;</button>	
			<strong><?php echo e($error); ?></strong>
		</div>
  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\good\resources\views/widgets/error.blade.php ENDPATH**/ ?>