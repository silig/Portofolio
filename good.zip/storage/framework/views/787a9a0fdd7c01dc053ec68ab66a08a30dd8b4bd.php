<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Users</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
			<?php echo $__env->make('widgets.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		    <table class="table table-striped" id="data-table" width="100%">
	            <thead>
		            <tr>
		                <th>ID</th>
		                <th>Name</th>
		                <th>Email</th>
		                <th>Role</th>
		                <th>Active</th>
		            </tr>
		        </thead>
		        <thead id="searchid">
	               	<tr>
	                  	<td></td>
	                  	<td></td>
	                  	<td></td>
	                  	<td></td>
	                  	<td></td>
	               	</tr>
	            </thead>
		    </table>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('js'); ?>
    <script>
    	$(function() {
    		alertAutoCLose()
    		var create = '';

			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-users')): ?>
	        create += '<a class="btn btn-success btn-sm" href="users/create"><i class="fa fa-plus"></i> Create</a>';
	        <?php endif; ?>

		    var tb = $('#data-table').DataTable({
		        processing: true,
		        serverSide: true,
		        language: {
		         	search: "",
		         	lengthMenu: '_MENU_ &nbsp; '+create
		      	},
		        ajax: 'users',
		        columns: [
		        	{ data: 'id', name: 'id'},
		            { data: 'name', name: 'name', render: function (data, type, row, meta) {
		            	var buttons = '';

		            	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-users')): ?>
		            	buttons += '<a href="users/'+row.id+'/edit" class="btn btn-info btn-xs">edit</a> ';
		            	<?php endif; ?>
		            	
		            	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-users')): ?>
		            	buttons += '<a href="users/'+row.id+'/delete" class="btn btn-info btn-xs" onclick="confirmation(event)">delete</a>';
		            	<?php endif; ?>
		            	
		            	return '<div>'+row.name+'</div><div class="action-button"> '+buttons+' </div>';
		            }},
		            { data: 'email', name: 'email' },
		            { data: 'role.name', name: 'role.name' },
		            { data: 'active', name: 'active' }
		        ]
		    });

		    $('#data-table #searchid td').each(function() {
		        $(this).html('<input type="text" class="form-control form-control-sm" data-id="'+$(this).index()+'"/>');
		   	});

		   	$('#data-table #searchid input').keyup(debounce(function () {
		      	tb.columns($(this).data('id')).search(this.value).draw();
		   	}, 500));
		});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\good\resources\views/users/list.blade.php ENDPATH**/ ?>