<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><a href="/<?php echo e(config('adminlte.dashboard_url')); ?>/users">Users</a> / <?php echo (isset($model)) ? 'Edit' : 'Create'; ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
	      	<?php if(isset($model)): ?>
			    <?php echo e(Form::model($model, ['id' => 'user-form'])); ?>

			<?php else: ?>
			    <?php echo e(Form::open(['id' => 'user-form'])); ?>

			<?php endif; ?>
	  		<?php echo $__env->make('widgets.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	  		<div class="row">
		  		<div class="col-6">
					<div class="form-group">
			    		<label>Name*</label>
			    		<?php echo Form::text('name',null, ['class' => 'form-control']); ?>

			  		</div>
		  		</div>
		  		<div class="col-6">
			  		<div class="form-group">
			    		<label>Email*</label>
			    		<?php echo Form::text('email',null, ['class' => 'form-control']); ?>

			  		</div>
		  		</div>
	  		</div>

	  		<div class="row">
		  		<div class="col-6">
			  		<div class="form-group">
			    		<label>Phone*</label>
			    		<?php echo Form::text('phone',null, ['class' => 'form-control']); ?>

			  		</div>
			  	</div>
		  		<div class="col-6">
			  		<div class="form-group">
			    		<label>Password* <small><i><?php echo (isset($model)) ? '(kosongkan jika tidak diubah)' : ''; ?></i></small></label>
			    		<input type="password" class="form-control" name="password">
			  		</div>
			  	</div>
	  		</div>

	  		<div class="row">
		  		<div class="col-6">
			  		<div class="form-group">
			    		<label>Role*</label>
			  			<?php echo Form::select('role_id', $roles, null, ['placeholder' => 'Select Role','class' => 'custom-select']); ?>

			  		</div>
			  	</div>
		  		<div class="col-6">
			  		<div class="form-group">
			    		<label>Active</label>
			    		<div class="form-check">
				    		<?php echo Form::checkbox('active', \App\Enum\Status::ACTIVE, 
				    		isset($model->active) && $model->active == \App\Enum\Status::ACTIVE ? true : false,  
				    		['class' => 'form-check-input']); ?>

				    	</div>
			  		</div>
			  	</div>
	  		</div>
  		</div>
      	<div class="card-footer">
	      	<?php echo $__env->make('widgets.submit_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      	</div>
      	<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.min.js')); ?>"></script>
<?php echo $validator->selector('#user-form'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\good\resources\views/users/form.blade.php ENDPATH**/ ?>