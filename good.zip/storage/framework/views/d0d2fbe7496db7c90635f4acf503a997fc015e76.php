<?php $__env->startSection('title', 'User Profile'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>User Profile</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
			<div class="row">
				<div class="col-md-6">
					<div class="callout callout-info">
						<h5>name</h5>
						<p><?php echo e($profile->name); ?></p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="callout callout-info">
						<h5>email</h5>
						<p><?php echo e($profile->email); ?></p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="callout callout-info">
						<h5>phone</h5>
						<p><?php echo e($profile->phone); ?></p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="callout callout-info">
						<h5>role</h5>
						<p><?php echo e($profile->role->name); ?></p>
					</div>
				</div>
			</div>
	    </div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\good\resources\views/auth/profil.blade.php ENDPATH**/ ?>