<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Form User</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Pendidikan</h3>
              </div>
              <form role="form" action="<?php echo e(route('update_pendidikan', $profil->id)); ?>" method="post">
              	<?php echo csrf_field(); ?>
                <div class="card-body">
                	<?php echo $__env->make('widgets.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                	<?php echo $__env->make('widgets.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                	<div id="pendidikan">
                	<?php $__empty_1 = true; $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendidikan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
                	<div class="row" >
                		<div class="col-sm-2">
			                  <div class="form-group">
			                    <label for="tahun">tahun mulai</label>
			                    <input type="input" class="form-control" name="tahun_mulai[]" placeholder="Enter.." value="<?php echo e($pendidikan->tahun_mulai); ?>">
			                    <input type="input" class="form-control" name="id[]" placeholder="Enter.." value="<?php echo e($pendidikan->id); ?>" hidden="">
			                  </div>
			            </div> 
			            <div class="col-sm-2">
			                  <div class="form-group">
			                    <label for="tahun">tahun selesai</label>
			                    <input type="input" class="form-control" name="tahun_selesai[]" placeholder="Enter.." value="<?php echo e($pendidikan->tahun_selesai); ?>">
			                  </div>
			            </div>  
			            <div class="col-sm-4">
			                  <div class="form-group">
			                    <label for="tahun">Nama Instansi</label>
			                    <input type="input" class="form-control" name="institusi[]" placeholder="Enter.." value="<?php echo e($pendidikan->institusi); ?>">
			                  </div>
			            </div>
			            <div class="col-sm-3">
			                  <div class="form-group">
			                    <label for="tahun">Jurusan</label>
			                    <input type="input" class="form-control" name="jurusan[]" placeholder="Enter.." value="<?php echo e($pendidikan->nama_jurusan); ?>">
			                  </div>
			            </div>  
			            <div class="col-sm-1">
			            	<div class="form-group">
			            		<label for="tahun">hapus</label>
			            	   	<a href="<?php echo e(route('del_pendidikan', $pendidikan->id)); ?>" class="btn btn-danger btn-sm" onclick="confirmation(event)">Del</a>
			            	</div>
			            </div>         
	                </div>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	                <div class="row" >
                		<div class="col-sm-2">
			                  <div class="form-group">
			                    <label for="tahun">tahun mulai</label>
			                    <input type="input" class="form-control" name="tahun_mulai[]" placeholder="Enter.." >
			                    <input type="input" class="form-control" name="id[]" placeholder="Enter.."  hidden="">
			                  </div>
			            </div> 
			            <div class="col-sm-2">
			                  <div class="form-group">
			                    <label for="tahun">tahun selesai</label>
			                    <input type="input" class="form-control" name="tahun_selesai[]" placeholder="Enter.." >
			                  </div>
			            </div>  
			            <div class="col-sm-4">
			                  <div class="form-group">
			                    <label for="tahun">Nama Instansi</label>
			                    <input type="input" class="form-control" name="institusi[]" placeholder="Enter.." >
			                  </div>
			            </div>
			            <div class="col-sm-3">
			                  <div class="form-group">
			                    <label for="tahun">Jurusan</label>
			                    <input type="input" class="form-control" name="jurusan[]" placeholder="Enter.." >
			                  </div>
			            </div>        
	                </div>
	                <?php endif; ?>
	                </div> 
	                <div class="col-sm-2">
	                	<input type="button" class="btn btn-info list_add" value="Tambah" onClick="addInput('pendidikan');"><br>
	                </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary float-right">Submit</button>
                </div>
              </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.min.js')); ?>"></script>
<script type="text/javascript">
	var counter = 1;
	var limit = 5;
	function addInput(divName){
	     if (counter == limit)  {
	          alert("You have reached the limit of adding " + counter + " inputs");
	     }
	     else {
	          var newdiv = document.createElement('div');
	          newdiv.innerHTML = 
	          			
	          			'<div class="row pendidikan_'+ (counter + 1) +'">'+
		          			'<div class="col-sm-2">'+
			                  '<div class="form-group">'+
			                    '<label for="tahun">tahun mulai</label>'+
			                    '<input type="input" class="form-control" name="tahun_mulai[]" placeholder="Enter..">'+
			                    '<input type="input" class="form-control" name="id[]" placeholder="Enter.." hidden>'+
			                  '</div>'+
				            '</div> '+
				            '<div class="col-sm-2">'+
				                  '<div class="form-group">'+
				                    '<label for="tahun">tahun selesai</label>'+
				                    '<input type="input" class="form-control" name="tahun_selesai[]" placeholder="Enter..">'+
				                  '</div>'+
				            '</div>  '+
				            '<div class="col-sm-4">'+
				                  '<div class="form-group">'+
				                    '<label for="tahun">Nama Instansi</label>'+
				                    '<input type="input" class="form-control" name="institusi[]" placeholder="Enter..">'+
				                  '</div>'+
				            '</div>'+
				            '<div class="col-sm-3">'+
				                  '<div class="form-group">'+
				                    '<label for="tahun">Jurusan</label>'+
				                    '<input type="input" class="form-control" name="jurusan[]" placeholder="Enter..">'+
				            	  '</div>'+
			            	'</div>'+
				            '<div class="col-sm-1">'+
			            	'<div class="form-group">'+
			            		'<label for="tahun">hapus</label>'+
			            	'<a href="<?php echo e(route("del_pendidikan", "null")); ?>" class="btn btn-danger btn-sm" onclick="confirmation(event)">Del</a>'+
			            	'</div>'+
			            '</div>'+  
			            '</div>';
	          document.getElementById(divName).appendChild(newdiv);
	          counter++;
	     }
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\good\resources\views/form/pendidikan.blade.php ENDPATH**/ ?>