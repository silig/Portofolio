<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Form User</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
	      <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Data Diri</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <form role="form" id="datadiri" files="true" action="<?php echo e(route('update-user', $profil->id)); ?>" method="post" enctype="multipart/form-data">
                	<?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" class="form-control" name="nama_lengkap" value="<?php echo e($profil->nama_lengkap); ?>" placeholder="Enter ...">
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <input type="text" class="form-control" name="jk" value="<?php echo e($profil->jenis_kelamin); ?>" placeholder="Enter ..." >
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Tempat Lahir</label>
                        <input type="text" class="form-control" name="tempat_lahir" value="<?php echo e($profil->tempat_lahir); ?>" placeholder="Enter ..." >
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Tanggal Lahir</label>
                        <input type="date" class="form-control" name="tgl_lahir" value="<?php echo e($profil->tgl_lahir); ?>" placeholder="Enter ..." >
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Agama</label>
                        <input type="text" class="form-control" name="agama" value="<?php echo e($profil->agama); ?>" placeholder="Enter ..." >
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Alamat</label>
                        <input type="text" class="form-control" name="alamat" value="<?php echo e($profil->alamat); ?>" placeholder="Enter ..." >
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>NIM</label>
                        <input type="text" class="form-control" name="nim" value="<?php echo e($profil->nim); ?>" placeholder="Enter ..." >
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Jurusan</label>
                        <input type="text" class="form-control" name="jurusan" value="<?php echo e($profil->jurusan); ?>" placeholder="Enter ..." >
                      </div>
                    </div>
                  </div>
                                          
                  <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group" >
                        <label>foto</label>
                        
                        <?php if(isset($profil->foto)): ?>
		                  <img  id="output" class="form-control"
		                       src="<?php echo e(asset('storage/uploads/foto/'.$profil->foto)); ?>"
		                       alt="User profile picture" style="width: 250px;height: 300px">
		                <?php else: ?>
		                  <img  id="output" class="form-control"
		                       src="<?php echo e(asset('image/default-user.png')); ?>"
		                       alt="User profile picture" style="width: 250px;height: 300px">
		                <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>foto <sup class="label label-success">(max 500kb)</sup></label>
                        <input type="file" class="form-control" name="foto" placeholder="Enter ..." accept="image/png, image/jpeg" onchange="loadFile(event)">
                        <p class="text-danger"><?php echo e($errors->first('foto')); ?></p>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Telepon</label>
                        <input type="text" class="form-control" name="phone" value="<?php echo e($profil->phone); ?>" placeholder="Enter ..." >
                        <p class="text-danger"><?php echo e($errors->first('phone')); ?></p>
                      </div>

                    </div>
                  </div>

                  <div class="row">
                    <div class="col-sm-12">
                      <div class="form-group" >
                        <label>Tentang anda</label>
                        <textarea class="form-control" rows="3" name="tentang" placeholder="Enter ..."><?php echo $profil->tentang; ?></textarea>
                      </div>
                    </div>
                  </div>
                  
                
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                  <button type="submit" class="btn btn-primary float-right">Update</button>
                  </form>
              </div>
            </div>
	    </div>	
	</div>

	<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Sosial Media</h3>
              </div>
              <form role="form" action="<?php echo e(route('update_sosmed',$profil->id)); ?>" method="post">
              	<?php echo csrf_field(); ?>
                <div class="card-body">
                	<div id="sosmed">
                	<?php $__currentLoopData = $sosmed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sosmed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                	<div class="row" >
                		<div class="col-sm-2">
			                  <div class="form-group">
			                    <label for="tahun">Sosial Media</label>
			                    <select class="form-control" name="sosial_media[]">
		                          <option value="facebook" <?php echo e($sosmed->sosial_media == "facebook" ? 'selected':''); ?>>Facebook</option>
		                          <option value="twitter" <?php echo e($sosmed->sosial_media == "twitter" ? 'selected':''); ?>>Twitter</option>
		                          <option value="linkedin" 
		                          <?php echo e($sosmed->sosial_media == "linkedin" ? 'selected':''); ?>>Linked in</option>
		                          <option value="instagram" <?php echo e($sosmed->sosial_media == "instagram" ? 'selected':''); ?>>Instagram</option>
		                        </select>
			                  </div>
			            </div> 
			            <div class="col-sm-5">
			                  <div class="form-group">
			                    <label for="tahun">Link</label>
			                    <input type="input" class="form-control" name="link[]" placeholder="Enter.." value="<?php echo e($sosmed->link); ?>">
			                    <input type="input" class="form-control" hidden name="id[]" placeholder="Enter.." value="<?php echo e($sosmed->id); ?>">
			                  </div>
			            </div>  
			            <div class="col-sm-1">
			            	<div class="form-group">
			            		<label for="tahun">hapus</label>
			            	   	<a href="<?php echo e(route('del_sosmed', $sosmed->id)); ?>" class="btn btn-danger btn-sm" onclick="confirmation(event)">Del</a>
			            	</div>
			            </div>         
	                </div>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
	                </div> 
	                <div class="col-sm-2">
	                	<input type="button" class="btn btn-info list_add" value="Tambah" onClick="addInput('sosmed');"><br>
	                </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary float-right">Submit</button>
                </div>
              </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.min.js')); ?>"></script>
<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('output');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
</script>
<script type="text/javascript">
	var counter = 1;
	var limit = 5;
	function addInput(divName){
	     if (counter == limit)  {
	          alert("You have reached the limit of adding " + counter + " inputs");
	     }
	     else {
	          var newdiv = document.createElement('div');
	          newdiv.innerHTML = 
	          			
	          			'<div class="row pendidikan_'+ (counter + 1) +'">'+
		          			'<div class="col-sm-2">'+
				                  '<div class="form-group">'+
				                    '<label for="tahun">Sosial Media</label>'+
				                    '<select class="form-control" name="sosial_media[]">'+
			                          '<option value="facebook">Facebook</option>'+
			                          '<option value="twitter" >Twitter</option>'+
			                          '<option value="linkedin">Linked in</option>'+
			                          '<option value="instagram" >Instagram</option>'+
			                        '</select>'+
				                  '</div>'+
				            '</div> '+
				            '<div class="col-sm-5">'+
				                  '<div class="form-group">'+
				                    '<label for="tahun">Link</label>'+
				                    '<input type="input" class="form-control" name="link[]" placeholder="Enter.." required>'+
				                  '</div>'+
				            '</div>  '+
				            '<div class="col-sm-1">'+
			            	'<div class="form-group">'+
			            		'<label for="tahun">hapus</label>'+
			            	  '<a class="btn btn-danger btn-sm hapus" data-id="pendidikan_'+ (counter + 1) +'" >Del</a>'+
			            	'</div>'+
			            '</div>'+  
			            '</div>';
	          document.getElementById(divName).appendChild(newdiv);
	          counter++;
	     }
	}
</script>
<script type="text/javascript">
   $(document).on('click','.hapus',function(){
    var tes = $(this).data("id");
    $('.'+tes).remove();
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\good\resources\views/profil/form.blade.php ENDPATH**/ ?>