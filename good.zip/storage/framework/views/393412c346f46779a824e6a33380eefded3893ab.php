<?php $__env->startSection('title', 'User Profile'); ?>



<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
          <div class="col-sm-6">
            <h1>User Profile</h1>
          </div>
          <div class="col-sm-6">
            
          </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
          <div class="col-md-3">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <?php if(isset($datadiri->foto)): ?>
                  <img class="profile-user-img img-fluid img-circle"
                       src="<?php echo e(asset('storage/uploads/foto/'.$datadiri->foto)); ?>"
                       alt="User profile picture">
                  <?php else: ?>
                  <img class="profile-user-img img-fluid img-circle"
                       src="<?php echo e(asset('image/default-user.png')); ?>"
                       alt="User profile picture">
                  <?php endif; ?>
                </div>

                <h3 class="profile-username text-center"><?php echo isset($datadiri->nama_lengkap) ? $datadiri->nama_lengkap: '('.$profile->name.')<span class="badge badge-danger right">default username</span>'; ?></h3>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Tempat lahir</b> <a class="float-right"><?php echo isset($datadiri->tempat_lahir) ? $datadiri->tempat_lahir : "<p style='background: red'>belum diisi</p>"; ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Tanggal lahir</b> <a class="float-right"><?php echo isset($datadiri->tgl_lahir) ? $datadiri->tgl_lahir : "<p style='background: red'>belum diisi</p>"; ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Jenis Kelamin</b> <a class="float-right"><?php echo isset($datadiri->jenis_kelamin) ? $datadiri->jenis_kelamin : "<p style='background: red'>belum diisi</p>"; ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Agama</b> <a class="float-right"><?php echo isset($datadiri->agama) ? $datadiri->agama : "<p style='background: red'>belum diisi</p>"; ?></a>
                  </li>
                </ul>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            <!-- About Me Box -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Data Mahasiswa</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-book mr-1"></i> Jurusan</strong>

                <p class="text-muted">
                  <?php echo isset($datadiri->jurusan) ? $datadiri->jurusan : "<p style='background: red'>belum diisi</p>"; ?>

                </p>

                <hr>

                <strong><i class="fas fa-book mr-1"></i> NIM</strong>

                <p class="text-muted">
                 <?php echo isset($datadiri->nim) ? $datadiri->nim : "<p style='background: red'>belum diisi</p>"; ?>

                </p>

                <hr>                

              </div>
              <!-- /.card-body -->
            </div>

            <!-- Contact Box -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Informasi kontak</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-phone mr-1"></i> Telepon</strong>

                <p class="text-muted">
                  <?php echo isset($datadiri->phone) ? $datadiri->phone : "<p style='background: red'>belum diisi</p>"; ?>

                </p>

                <hr>

                <strong><i class="fas fa-envelope mr-1"></i> Email</strong>

                <p class="text-muted">
                  <?php echo isset($email) ? $email : "<p style='background: red'>belum diisi</p>"; ?>

                </p>

                <hr>

                <strong><i class="fas fa-map-marker-alt mr-1"></i> Alamat</strong>

                <p class="text-muted">
                  <?php echo isset($datadiri->alamat) ? $datadiri->alamat : "<p style='background: red'>belum diisi</p>"; ?></p>

                <hr>

                <strong><i class="fas fa-link mr-1"></i> Sosial Media</strong>

                <p class="text">
                    <ul>
                      <?php $__empty_1 = true; $__currentLoopData = $sosmed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sosmed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <?php
                          $removeChar = ["https://", "http://"];
                          $result = str_replace($removeChar, "", $sosmed->link);
                          ?>
                          <li><a href="<?php echo e($sosmed->link); ?>"><?php echo e($result); ?></a></li>
                          
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p style='background: red'>belum diisi</p>
                      <?php endif; ?>
                    </ul>
                </p>

                <hr>

                

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#datadiri" data-toggle="tab">Data Diri</a></li>
                  
                  
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  
                  
                  <div class="active tab-pane" id="datadiri">
                    
                    <div class="card card-inverse">
                      
                        <div class="card-header">
                        <h3 class="card-title">
                          <i class="fas fa-address-card"></i>
                          <b>Tentang Saya</b></h3>
                        </div>
                      <div class="callout callout-danger">
                        <div class="card-body">
                          
                            <?php echo isset($datadiri->tentang) ? $datadiri->tentang : "<a style='background: red'>belum diisi</a>"; ?>

                          
                        </div>
                      </div>
                    </div>
                    

                    <div class="card card-inverse">
                      
                        <div class="card-header">
                        <h3 class="card-title">
                          <i class="fas fa-university"></i>
                          <strong>Riwayat Pendidikan</strong></h3>
                        </div>
                      <div class="callout callout-danger">
                        <div class="card-body">
                          <ul>
                            <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendidikan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($pendidikan->tahun_mulai); ?> - <?php echo e($pendidikan->tahun_selesai); ?> - <?php echo e($pendidikan->nama_jurusan.' '.$pendidikan->institusi); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>  
                        </div>
                      </div>
                      
                          
                      
                    </div>
                    

                    <div class="card card-inverse">
                      
                        <div class="card-header">
                        <h3 class="card-title">
                          <i class="fas fa-briefcase"></i>
                          <b>Pengalaman</b></h3>
                        </div>
                      <div class="callout callout-danger">
                        <div class="card-body">
                          <ul>
                            <?php $__empty_1 = true; $__currentLoopData = $pengalaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengalaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <li><b><?php echo e($pengalaman->pengalaman); ?></b></li><br>
                              <p><?php echo e($pengalaman->penjelasan); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                              <a style="background: red">Belum diisi</a> 
                            <?php endif; ?>
                          </ul>
                        </div>
                      </div>
                    
                          
                      
                    </div>
                    
                    <div class="card card-default">
                      
                        <div class="card-header">
                        <h3 class="card-title">
                          <i class="fas fa-medal"></i>
                          <b>Prestasi</b></h3>
                        </div>
                      <div class="callout callout-danger">  
                        <div class="card-body">
                          <ul>
                            <?php $__empty_1 = true; $__currentLoopData = $prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <li><b><?php echo e($prestasi->tahun); ?></b></li><br>
                              <p><?php echo e($prestasi->prestasi); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                              <a style="background: red">Belum diisi</a> 
                            <?php endif; ?>
                          </ul>
                        </div>
                      </div>
                      
                          
                        
                    </div>
                    
                    <div class="card card-default">
                      
                        <div class="card-header">
                        <h3 class="card-title">
                          <i class="fas fa-running"></i>
                          <b>Hobi</b></h3>
                        </div>
                      <div class="callout callout-danger">  
                        <div class="card-body">
                          <ul>
                            <?php $__empty_1 = true; $__currentLoopData = $hobi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <li><b><?php echo e($hobi->nama_hobi); ?></b></li><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                              <a style="background: red">Belum diisi</a> 
                            <?php endif; ?>
                          </ul>
                        </div>
                      </div>
                      
                          
                        
                    </div>
                    

                    <div class="card card-inverse">
                      
                        <div class="card-header">
                          <h3 class="card-title">
                            <i class="fas fa-brain"></i>
                            <b>Skill</b></h3>
                        </div>
                        <div class="callout callout-danger">
                          <div class="card-body">
                                  <table class="table table-condensed">
                                    <thead>                  
                                      <tr>
                                        <th style="width: 30%">Skill</th>
                                        <th style="width: 50%">Penguasaan</th>
                                        <th style="width: 20%">Label</th>
                                      </tr>
                                    </thead>
                                  <tbody>
                                    <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td><?php echo e($skill->skill); ?></td>
                                      <td>
                                        <div class="progress progress-xs">
                                          <div class="progress-bar progress-bar-danger" style="width: <?php echo e($skill->kemahiran); ?>%"></div>
                                        </div>
                                      </td>
                                      <td><span class="badge bg-success"><?php echo e($skill->kemahiran); ?>%</span></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                                </table>
                          </div>
                        </div>

                          
                          
                    </div>
                    
                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col -->
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\good\resources\views/search/result.blade.php ENDPATH**/ ?>