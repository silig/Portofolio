<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="alert alert-success">
			<marquee>Halloo <b><?php echo e(Auth::user()->name); ?></b>! Selamat datang di web sistem informasi portofolio </marquee>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
    	<div class="card col-md-12">
    		<div class="alert alert-danger alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h5><i class="icon fas fa-ban"></i> Panduan!</h5>
                  Cukup dengan mengisi data di menu profile, dan kemudian cetak!
            </div>
	    	<div class="card-body" style="text-align: center;">
	    		<img src="<?php echo e(asset('image/Undip.png')); ?>" style="width: 200px;height: 230px">
	    		<p><h3>Fakultas Teknik</h3></p>
	    		<p><h3>Universitas Diponegoro</h3></p>
	    	</div>
	    </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\good\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>