<div class="btn-group float-right">
  	<button type="button" class="btn btn-warning" onclick="window.history.go(-1);">
  		<i class="fa fa-arrow-circle-left"></i> Back</button>
		<button type="submit" class="btn btn-success pull-right">
			<i class="fa fa-save"></i> Save</button>
</div><?php /**PATH C:\xampp\htdocs\good\resources\views/widgets/submit_button.blade.php ENDPATH**/ ?>