<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 	<?php if(Session::has($key)): ?>
     	<div class="alert alert-<?php echo e($key); ?>">
			<button type="button" class="close" data-dismiss="alert">&times;</button>	
			<strong><?php echo e(Session::get($key)); ?></strong>
		</div>
 	<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\good\resources\views/widgets/message.blade.php ENDPATH**/ ?>